import { configureStore } from '@reduxjs/toolkit';
import tableReducer from './features/tableSlice';
import roomReducer from './features/roomSlice';

const store = configureStore({
  reducer: {
    tables: tableReducer,
    rooms: roomReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export default store;
