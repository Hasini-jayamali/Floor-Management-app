import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface Table {
  id: string;
  name: string;
  minCovers: number;
  maxCovers: number;
  online: boolean;
}

interface TableState {
  tables: Table[];
}

const initialState: TableState = {
  tables: [],
};

const tableSlice = createSlice({
  name: 'tables',
  initialState,
  reducers: {
    addTable: (state, action: PayloadAction<Table>) => {
      state.tables.push(action.payload);
    },
    updateTable: (state, action: PayloadAction<Table>) => {
      const index = state.tables.findIndex(
        (table) => table.id === action.payload.id
      );
      if (index !== -1) {
        state.tables[index] = action.payload;
      }
    },
    removeTable: (state, action: PayloadAction<string>) => {
      state.tables = state.tables.filter(
        (table) => table.id !== action.payload
      );
    },
  },
});

export const { addTable, updateTable, removeTable } = tableSlice.actions;
export default tableSlice.reducer;
