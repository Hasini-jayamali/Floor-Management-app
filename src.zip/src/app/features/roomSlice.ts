import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface Room {
  id: string;
  name: string;
}

interface RoomState {
  rooms: Room[];
}

const initialState: RoomState = {
  rooms: [],
};

const roomSlice = createSlice({
  name: 'rooms',
  initialState,
  reducers: {
    addRoom: (state, action: PayloadAction<Room>) => {
      state.rooms.push(action.payload);
    },
    removeRoom: (state, action: PayloadAction<string>) => {
      state.rooms = state.rooms.filter((room) => room.id !== action.payload);
    },
  },
});

export const { addRoom, removeRoom } = roomSlice.actions;
export default roomSlice.reducer;
